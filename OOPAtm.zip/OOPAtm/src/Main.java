/**
 *
 * @author tugba
 */
public class Main 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // Hesap Class'ı hesap işlemlerini yapacak.
        // ATM class ı ise atm mizi çalıştıracak.
        ATM atm = new ATM();
        
        Hesap hesap = new Hesap("Tuğba", "12345", 2000);
        
        atm.calis(hesap);
        System.out.println("Programdan çıkılıyor...");
    }
    
}
