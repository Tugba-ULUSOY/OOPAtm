import java.util.Scanner;

/**
 *
 * @author tugba
 */
public class Login 
{
    public boolean login(Hesap hesap) // Hesap class ımıza ulaşmak için hesap referansı oluşturduk. 
    {
        Scanner scanner = new Scanner(System.in);
        String kullanici_adi;
        String parola;
        
        System.out.print("Kullanıcı Adı: ");
        kullanici_adi = scanner.nextLine();
        
        System.out.print("Parola: ");
        parola = scanner.nextLine();
        
        if(hesap.getKullanici_adi().equals(kullanici_adi) && hesap.getParola().equals(parola))
        {
            return true;
        }
        
        else
        {
            return false;
        }
        
    }
}
